"""Common initial parameters, common eta and eta/2, exact autograd predictions."""

from pathlib import Path

import numpy as np

from dependent_rollouts.artifacts import sha256, write_json, write_jsonl
from dependent_rollouts.interventions import perturb
from dependent_rollouts.statistics import importance_reward

from .bank import assert_independent, read_bank
from .gradient_audit import aggregate_gradient, dot, load_gradient
from .sample import load_model, token_logps


def evaluate(model, rows):
    import torch

    with torch.no_grad():
        return np.array(
            [float(token_logps(model, r["prompt_ids"], r["response_ids"]).sum()) for r in rows]
        )


def branch(shared_path, independent_path, evaluation_bank, output, step, readouts=()):
    if not np.isfinite(step) or step <= 0:
        raise ValueError("Freeze a positive step on Dev")
    sm, _ = load_gradient(shared_path)
    im, _ = load_gradient(independent_path)
    manifest, groups = read_bank(evaluation_bank)
    if (
        sm["arm"] != "shared"
        or im["arm"] != "independent"
        or sm["bank_sha256"] != im["bank_sha256"]
    ):
        raise ValueError("Need S/I from identical candidate bank")
    if sm["config"] != im["config"] or sm["config"] != manifest["config"]:
        raise ValueError("Checkpoint contract mismatch")
    _, treatment = read_bank(sm["bank"])
    if sha256(Path(sm["bank"]) / "rows.jsonl") != sm["bank_sha256"]:
        raise ValueError("Treatment bank changed")
    assert_independent(treatment, groups)
    treatment_rows = [r for group in treatment.values() for r in group]
    if any(r["split"] != "C" for r in treatment_rows):
        raise ValueError("Gradient directions require the C split")
    rows = [r for group in groups.values() for r in group]
    if any(r["split"] != "D" for r in rows):
        raise ValueError("Local consequences require independent D split")
    model, _ = load_model(manifest["config"])
    base = evaluate(model, rows)
    if max(abs(base - np.array([sum(r["sampling_token_logp"]) for r in rows]))) > manifest[
        "config"
    ]["token_logp_tolerance"] * max(len(r["response_ids"]) for r in rows):
        raise ValueError("D bank off checkpoint")
    out = Path(output)
    out.mkdir(parents=True, exist_ok=False)
    results, values = {}, {}
    prompt_ids = sorted({r["prompt_id"] for r in rows})
    for arm, directory in (("shared", shared_path), ("independent", independent_path)):
        _, direction = load_gradient(directory)
        predictions = []
        for readout in readouts:
            rm, rg = load_gradient(readout)
            if rm["config"] != manifest["config"] or rm.get("kind") != "Dev_frozen_function":
                raise ValueError("Primary readout must be Dev-frozen at the same contract")
            definitions = rm["definitions"]
            baseline = sum(
                r["coefficient"] * lp
                for r, lp in zip(definitions, evaluate(model, definitions), strict=True)
            )
            slope = dot(rg, direction)
            del rg
            for eta in (step, step / 2):
                with perturb(model, direction, eta):
                    new = sum(
                        r["coefficient"] * lp
                        for r, lp in zip(definitions, evaluate(model, definitions), strict=True)
                    )
                predictions.append(
                    {
                        "readout": str(readout),
                        "step": eta,
                        "slope": slope,
                        "predicted_change": eta * slope,
                        "actual_change": new - baseline,
                        "residual": new - baseline - eta * slope,
                    }
                )
        targets = {}
        for target in ("average", "suite"):
            weights = []
            for prompt in prompt_ids:
                pr = [r for r in rows if r["prompt_id"] == prompt]
                for row in pr:
                    reward = (
                        np.mean(row["test_verdicts"])
                        if target == "average"
                        else np.prod(row["test_verdicts"])
                    )
                    weights.append((row, float(reward) / (len(pr) * len(prompt_ids))))
            g, _ = aggregate_gradient(model, weights, manifest["config"]["token_logp_tolerance"])
            targets[target] = {
                "aggregate_slope": dot(g, direction),
                "uncertainty": "D_estimated_C_frozen_no_joint_CI",
            }
            del g
        for eta in (step, step / 2):
            with perturb(model, direction, eta):
                new = evaluate(model, rows)
            values[f"{arm}:{eta}"] = new
            summaries = {}
            for prompt in prompt_ids:
                idx = [i for i, r in enumerate(rows) if r["prompt_id"] == prompt]
                summaries[prompt] = {
                    target: importance_reward(
                        [
                            float(
                                np.mean(rows[i]["test_verdicts"])
                                if target == "average"
                                else np.prod(rows[i]["test_verdicts"])
                            )
                            for i in idx
                        ],
                        base[idx],
                        new[idx],
                    )
                    for target in ("average", "suite")
                }
            results[f"{arm}:{eta}"] = summaries
        write_json(
            out / f"{arm}_predictions.json", {"fixed_function": predictions, "D_targets": targets}
        )
        del direction
    write_jsonl(
        out / "evaluation.jsonl",
        [
            {
                "trajectory_id": r["trajectory_id"],
                "prompt_id": r["prompt_id"],
                "old_logp": float(base[i]),
                "new_logps": {k: float(v[i]) for k, v in values.items()},
            }
            for i, r in enumerate(rows)
        ],
    )
    report = {
        "status": "local_function_and_importance_diagnostic_not_pilot_GO",
        "step": step,
        "independent_generation_after_step": False,
        "per_prompt": results,
        "shared_gradient": sm,
        "independent_gradient": im,
        "evaluation_sha256": sha256(Path(evaluation_bank) / "rows.jsonl"),
    }
    write_json(out / "receipt.json", report)
    return report
